import math
r = 3
h = 5
v = math.pi*r**2*h
print(v)